import React from 'react';
import TipoCapacitadorList from './CursoList';

const TiposCapacitador = () => {
  return (
    <div>
      <h2>Gestión de Cursos</h2>
      <TipoCapacitadorList />
    </div>
  );
};

export default TiposCapacitador;