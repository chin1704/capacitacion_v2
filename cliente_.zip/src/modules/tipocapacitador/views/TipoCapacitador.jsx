import React from 'react';
import TipoCapacitadorList from './TipoCapacitadorList';

const TiposCapacitador = () => {
  return (
    <div>
      <h2>Gestión de Tipos de Capacitador</h2>
      <TipoCapacitadorList />
    </div>
  );
};

export default TiposCapacitador;