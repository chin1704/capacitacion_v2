import React from 'react';
import CapacitadorList from './CapacitadorList';

const Capacitadores = () => {
  return (
    <div>
      <h2>Gestión de Capacitadores</h2>
      <CapacitadorList />
    </div>
  );
};

export default Capacitadores;
